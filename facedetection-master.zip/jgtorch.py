import cv2
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading

class FaceDetectionApp:
    def __init__(self, root):
        self.root = root
        self.root.title('人脸检测程序')
        self.root.geometry('600x500')

        self.label = tk.Label(root, text='选择图片、视频或开启摄像头进行人脸检测')
        self.label.pack(pady=10)

        self.image_button = tk.Button(root, text='加载图片', command=self.load_image)
        self.image_button.pack(pady=5)

        self.video_button = tk.Button(root, text='加载视频', command=self.load_video)
        self.video_button.pack(pady=5)

        self.camera_button = tk.Button(root, text='调用摄像头', command=self.start_camera)
        self.camera_button.pack(pady=5)

        self.close_button = tk.Button(root, text='关闭检测', command=self.close_detection)
        self.close_button.pack(pady=5)

        self.image_label = tk.Label(root)
        self.image_label.pack(expand=True, fill=tk.BOTH)

        self.video_thread = None

    def load_image(self):
        image_path = filedialog.askopenfilename(title='选择图片', filetypes=[('Images', '*.png;*.jpg;*.jpeg')])
        if image_path:
            self.detect_faces_in_image(image_path)

    def load_video(self):
        video_path = filedialog.askopenfilename(title='选择视频', filetypes=[('Videos', '*.mp4;*.avi')])
        if video_path:
            self.start_video(video_path)

    def detect_faces_in_image(self, image_path):
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

        try:
            img = cv2.imread(image_path)
            if img is None:
                raise ValueError("无法读取图像，检查路径是否正确。")

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

            self.update_image(img)
        except Exception as e:
            messagebox.showerror("错误", str(e))

    def update_image(self, frame):
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb_image)
        img_tk = ImageTk.PhotoImage(image=img)
        self.image_label.config(image=img_tk)
        self.image_label.image = img_tk  # Keep a reference

    def start_video(self, video_path):
        if self.video_thread is not None and self.video_thread.is_alive():
            self.close_detection()
        self.video_thread = threading.Thread(target=self.run_video, args=(video_path,))
        self.video_thread.start()

    def run_video(self, video_path):
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        cap = cv2.VideoCapture(video_path)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            self.update_image(frame)

        cap.release()

    def start_camera(self):
        if self.video_thread is not None and self.video_thread.is_alive():
            self.close_detection()
        self.video_thread = threading.Thread(target=self.run_camera)
        self.video_thread.start()

    def run_camera(self):
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        cap = cv2.VideoCapture(0)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            self.update_image(frame)

        cap.release()

    def close_detection(self):
        if self.video_thread is not None and self.video_thread.is_alive():
            self.video_thread.join(timeout=1)  # Wait for the thread to finish safely
        self.image_label.config(image='')  # Clear the image label

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceDetectionApp(root)
    root.protocol("WM_DELETE_WINDOW", app.close_detection)  # Handle window close
    root.mainloop()
