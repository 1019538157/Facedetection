import cv2

def detect_faces_in_image(image_path):
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

    output_image_path = "output_image.jpg"
    cv2.imwrite(output_image_path, img)
    print(f"检测到 {len(faces)} 张人脸，已保存为 {output_image_path}")

    # 显示结果
    cv2.imshow('Detected Faces', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    image_path = 'test.jpg'  # 替换为你的图片路径
    detect_faces_in_image(image_path)
