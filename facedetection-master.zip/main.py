import sys
import cv2
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout, QFileDialog, QSizePolicy
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt, QThread, pyqtSignal


class FaceDetectionThread(QThread):
    update_signal = pyqtSignal(QImage)

    def __init__(self, source):
        super().__init__()
        self.source = source
        self.face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        self.cap = cv2.VideoCapture(source)

    def run(self):
        while self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            self.update_signal.emit(self.convert_cv_qt(frame))

        self.cap.release()

    def convert_cv_qt(self, frame):
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        return qt_image.copy()  # Make a copy to avoid segmentation fault due to QImage using temporary buffer

    def stop(self):
        self.cap.release()
        self.terminate()


class FaceDetectionApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.video_thread = None

    def initUI(self):
        self.setWindowTitle('人脸检测程序')
        self.setGeometry(100, 100, 600, 500)

        self.layout = QVBoxLayout()

        self.label = QLabel('选择图片、视频或开启摄像头进行人脸检测')
        self.layout.addWidget(self.label)

        self.image_button = QPushButton('加载图片')
        self.image_button.clicked.connect(self.load_image)
        self.layout.addWidget(self.image_button)

        self.video_button = QPushButton('加载视频')
        self.video_button.clicked.connect(self.load_video)
        self.layout.addWidget(self.video_button)

        self.camera_button = QPushButton('调用摄像头')
        self.camera_button.clicked.connect(self.start_camera)
        self.layout.addWidget(self.camera_button)

        self.close_button = QPushButton('关闭检测')
        self.close_button.clicked.connect(self.close_detection)
        self.layout.addWidget(self.close_button)

        self.image_label = QLabel()
        self.image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.image_label.setScaledContents(True)
        self.layout.addWidget(self.image_label)

        self.setLayout(self.layout)

    def load_image(self):
        image_path, _ = QFileDialog.getOpenFileName(self, '选择图片', '', 'Images (*.png *.jpg *.jpeg)')
        if image_path:
            self.detect_faces_in_image(image_path)

    def load_video(self):
        video_path, _ = QFileDialog.getOpenFileName(self, '选择视频', '', 'Videos (*.mp4 *.avi)')
        if video_path:
            self.start_video(video_path)

    def detect_faces_in_image(self, image_path):
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

        try:
            img = cv2.imread(image_path)
            if img is None:
                raise ValueError("无法读取图像，检查路径是否正确。")

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

            self.update_image(self.convert_cv_qt(img))  # 使用当前类的 convert_cv_qt 方法
        except Exception as e:
            self.image_label.setText(f"错误: {str(e)}")
            print(f"发生错误: {str(e)}")

    def convert_cv_qt(self, frame):
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        return qt_image.copy()

    def start_video(self, video_path):
        if self.video_thread and self.video_thread.isRunning():
            self.video_thread.stop()
        self.video_thread = FaceDetectionThread(video_path)
        self.video_thread.update_signal.connect(self.update_image)
        self.video_thread.start()

    def start_camera(self):
        if self.video_thread and self.video_thread.isRunning():
            self.video_thread.stop()
        self.video_thread = FaceDetectionThread(0)
        self.video_thread.update_signal.connect(self.update_image)
        self.video_thread.start()

    def update_image(self, q_img):
        self.image_label.setPixmap(QPixmap.fromImage(q_img).scaled(self.image_label.size(), Qt.KeepAspectRatio))

    def close_detection(self):
        if self.video_thread and self.video_thread.isRunning():
            self.video_thread.stop()  # 停止线程
            self.video_thread.quit()  # 请求线程退出
            self.video_thread.wait()  # 等待线程安全退出
        self.image_label.clear()  # 清空图像标签

    def closeEvent(self, event):
        self.close_detection()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FaceDetectionApp()
    window.show()
    sys.exit(app.exec_())
